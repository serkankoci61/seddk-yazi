# Yazı Türleri, Şablonlar ve Zorunlu Bilgiler

Her tür için: Konu kalıbı, İlgi, gövde iskeleti, toplanacak bilgiler, tipik ekler.
`[●...]` yer tutucuları kullanıcıdan gelmeyen bilgiler içindir; uydurma veri yazma.

Ortak giriş paragrafı (her yazıda ilk paragraf, tür cümlesi sonda eklenir):
> İlgi (a) yazınız ile Sigortacılık ve Özel Emeklilik Düzenleme ve Denetleme Kurulu'nun 23.09.2026 tarih ve 1937 sayılı Kararı uyarınca Şirketimizin yakın izleme kapsamına alındığı bildirilmiştir.

Ortak kapanış cümleleri:
- Bildirim/bilgi yazıları: "Bilgilerinize arz ederiz."
- Onay/talep yazıları: "Gereğini ve onayınızı arz ederiz."
- Düzeltme/ek bilgi: "Bilgilerinize ve gereğine arz ederiz."

---

## 1. Ödeme bildirimi (ana faaliyet dışı, 100.000 TL üzeri)

**Kapsam:** 1937 sayılı Karar md. 1 — komisyon, hasar, reasürans, maaş, vergi ve diğer yasal yükümlülükler dışındaki, tek tek 100.000 TL'yi aşan ödemeler.

**Konu:** `Yakın İzleme Kapsamında Ödeme Bilgilendirmesi ([●başlangıç] – [●bitiş] Dönemi)` (tek ödeme ise: `... Ödeme Bilgilendirmesi ([●alıcı unvanı])`)

**İlgi:** (a) ana_ilgi.

**Gövde iskeleti:**
1. Ortak giriş + "Anılan Karar kapsamında, ana sigortacılık faaliyeti dışında kalan ve 100.000 TL'yi aşan ödemelere ilişkin bilgiler, [●dönem] dönemi için aşağıdaki tabloda ve Ek'te sunulmuştur."
2. Tablo: Sıra | Ödeme Tarihi | Alıcı Unvanı | Ödeme Nedeni (fatura/sözleşme no) | Tutar (TL) | Ödeme Kanalı/Banka | Dayanak (YK kararı / Kurum onayı)
3. Toplam satırı.
4. Beyan: "Tabloda yer alan ödemeler komisyon, hasar, reasürans, maaş, vergi ve diğer yasal yükümlülük niteliğinde değildir; hukuk dosyaları kapsamındaki ödemeler ise ayrıca günlük olarak bildirilmektedir."
5. Kapanış: "Bilgilerinize arz ederiz."

**Toplanacak bilgiler:** ödeme tarihi, alıcı, neden, tutar (KDV dahil/hariç belirtilerek), para birimi ve kur, ödeme kanalı, dayanak belge, ilgili sözleşme/YK kararı/Kurum onay yazısı tarih-sayısı.
**Tipik ekler:** ödeme dekontları, fatura suretleri, (varsa) sözleşme ve onay yazısı, ödeme listesi (Excel).

---

## 2. Yönetim kurulu kararı bildirimi

**Konu:** `Yakın İzleme Kapsamında Yönetim Kurulu Kararının Bildirilmesi ([●karar tarihi] Tarih ve [●karar no] Sayılı Karar)`

**Gövde iskeleti:**
1. Ortak giriş + "Anılan Karar uyarınca Şirketimiz Yönetim Kurulu'nun [●GG.AA.YYYY] tarih ve [●no] sayılı kararının sureti yakın izleme kapsamında ilişikte sunulmuştur."
2. Kısa karar özeti (konu, alınan karar, varsa tutar/yükümlülük, uygulama tarihi). Özet, kararın içeriğini değiştirmemeli; bire bir ek surete atıf yapılmalı.
3. Kararın Kurum onayına tabi bir işlem içerip içermediği (ör. >500.000 TL sözleşme) — içeriyorsa ayrı onay yazısına atıf.
4. Kapanış: "Bilgilerinize arz ederiz."

**Not:** Kararda "yönetim kurulu kararları" ifadesi kapsam bakımından geniş okunabilir; kullanıcı aksini teyit etmedikçe tüm YK kararlarının bildirildiği varsayılır. Bu varsayımı kullanıcıya hatırlat.
**Tipik ekler:** YK kararı (imzalı/onaylı suret veya e-imzalı örnek), varsa karara dayanak sunum/rapor.

---

## 3. Dış hizmet alımı bildirimi

**Konu:** `Yakın İzleme Kapsamında Dış Hizmet Alımı Bilgilendirmesi ([●hizmet sağlayıcı unvanı])`

**Gövde iskeleti:**
1. Ortak giriş + "Anılan Karar kapsamında, aşağıda bilgileri yer alan dış hizmet alımı hakkında Kurumunuza bilgi verilmesi amaçlanmaktadır."
2. Bilgi tablosu (iki sütun: Başlık | Bilgi): Hizmet sağlayıcı unvanı / vergi no / adres; hizmetin konusu ve kapsamı; hizmetin Şirket faaliyetlerindeki yeri (kritik/önemli mi); sözleşme tarihi ve süresi; bedel (KDV durumu, ödeme planı); alım gerekçesi; yetkili onayı (YK kararı/yetki dokümanı); risk/uyum değerlendirmesi özeti; varsa ilişkili taraf durumu.
3. Bedel 500.000 TL'yi aşıyor ve hizmet ana faaliyet dışıysa: "Sözleşme bedeli 500.000 TL'yi aştığından Kurum onayı için ayrıca [●tarih/sayı] yazımızla başvurulmuştur" (bu durumda tür 4 de hazırlanmalı; sözleşme imzadan önce onaya gitmelidir).
4. Kapanış: "Bilgilerinize arz ederiz."

**Tipik ekler:** sözleşme/teklif, hizmet seviyesi (SLA) dokümanı, risk değerlendirme formu, YK/yetki kararı.

---

## 4. Sözleşme onay talebi (ana faaliyet dışı, 500.000 TL üzeri)

**Kapsam:** 1937 sayılı Karar md. 2 — yükümlülük doğuran ve tutarı 500.000 TL'yi aşan tüm sözleşmeler Kurum onayına tabidir. Onay, sözleşme imzalanmadan önce alınmalıdır.

**Konu:** `500.000 TL Üzerindeki Sözleşmeye İlişkin Kurum Onayı Talebi ([●sözleşme konusu] – [●karşı taraf unvanı])`

**Gövde iskeleti:**
1. Ortak giriş + "Anılan Karar uyarınca, sigortacılık ana faaliyeti dışında yükümlülük doğuran ve tutarı 500.000 TL'yi aşan sözleşmeler Kurumunuzun onayına tabi tutulmuştur. Bu çerçevede aşağıda özeti sunulan sözleşme için onayınız talep edilmektedir."
2. Bilgi tablosu: Karşı taraf (unvan, vergi no, adres); sözleşme konusu; sözleşme süresi ve başlangıç tarihi; toplam bedel (rakam ve yazı ile, KDV dahil/hariç, para birimi ve kur); ödeme planı; fesih/cezai şart/otomatik yenileme hükümleri özeti; ihtiyaç ve seçim gerekçesi (teklif karşılaştırması); bütçe karşılığı; Şirket yetkili organ kararı; ilişkili taraf durumu.
3. Taahhüt: "Sözleşme, Kurumunuzun onayı alınmadan imzalanmayacak ve yürürlüğe girmeyecektir; sözleşme kapsamındaki ödemelerden 100.000 TL'yi aşanlar ayrıca yakın izleme kapsamında bildirilecektir."
4. Kapanış: "Gereğini ve onayınızı arz ederiz." (Varsa istenen cevap tarihi: "[●GG.AA.YYYY] tarihine kadar değerlendirilmesini rica ederiz.")

**Tipik ekler:** sözleşme taslağı (sayfa sayısıyla), teklifler/karşılaştırma tablosu, YK kararı, ihtiyaç gerekçe raporu, karşı tarafın imza sirküleri/faaliyet belgesi (gerekiyorsa), bütçe/ödenek belgesi.

---

## 5. Hukuk dosyaları ödeme bildirimi (günlük)

**Kapsam:** 1937 sayılı Karar md. 4 — hukuk dosyaları kapsamında yapılan ödemeler Kuruma günlük bildirilir; serbest bırakılan tutar yalnızca hukuk dosyalarında kullanılır.

**Konu:** `Hukuk Dosyaları Kapsamında Yapılan Ödemelerin Günlük Bildirimi ([●GG.AA.YYYY])`

**Gövde iskeleti:**
1. Ortak giriş + "Anılan Karar uyarınca, [●GG.AA.YYYY] tarihinde hukuk dosyaları kapsamında yapılan ödemelere ilişkin bilgiler aşağıda sunulmuştur."
2. Tablo: Sıra | Dosya No | Mahkeme/İcra Dairesi | Dosya Türü | Alıcı (vekil/icra dairesi/taraf) | Ödeme Tutarı (TL) | Ödeme Kanalı | Dekont No
3. Toplam satırı.
4. Bakiye tablosu (küçük): Serbest bırakılan toplam tutar (20.000.000 TL) | Önceki gün sonu kullanılan kümülatif tutar | Bugünkü ödeme toplamı | Kalan serbest tutar.
5. Beyan: "Serbest bırakılan tutardan yapılan çekimlerin tamamı yukarıda listelenen hukuk dosyası ödemeleri için kullanılmış olup başka bir amaçla kullanılmamıştır."
6. Kapanış: "Bilgilerinize arz ederiz."

**Toplanacak bilgiler:** yukarıdaki tablo alanları; hesap bakiyesi; önceki günlerin kümülatifi.
**Tipik ekler:** dekontlar, ödeme listesi (Excel), (gerekiyorsa) icra/mahkeme ödeme emri.
**KVKK:** gerçek kişi alıcıların T.C. kimlik no, IBAN gibi verileri yazı gövdesinde yer almamalı; gerekliyse yalnızca ekte, asgari düzeyde.

---

## 6. Hukuk ödemeleri hesabı bildirimi (ilk/tek seferlik veya değişiklikte)

**Kapsam:** 1937 sayılı Karar md. 4 — 20.000.000 TL'lik tutar, "Şirketiniz tarafından belirlenecek hesapta" tutulacak. Hesap belirlendiğinde ve değiştiğinde Kuruma bildirilmelidir.

**Konu:** `Hukuk Dosyası Ödemelerine İlişkin Hesap Bildirimi ve Serbest Tutar Kullanım Taahhüdü`

**Gövde iskeleti:**
1. Ortak giriş + "Anılan Karar'ın ilgili maddesi uyarınca serbest bırakılacak 20.000.000 TL'lik tutarın tutulacağı hesap aşağıda bildirilmiştir."
2. Tablo: Banka | Şube | Hesap Adı | IBAN | Para Birimi | Serbest Tutar.
3. Taahhüt: "Söz konusu tutar yalnızca hukuk dosyaları kapsamındaki ödemelerde kullanılacak, ödemeler günlük olarak Kurumunuza bildirilecektir."
4. Kapanış: "Bilgilerinize arz ederiz."

**Tipik ekler:** bankadan hesap/bloke durumu yazısı (varsa).

---

## 7. İnternet bankacılığı yetki kaldırma uygulaması bildirimi (isteğe bağlı)

**Kapsam:** 1937 sayılı Karar md. 3 — Şirketin internet bankacılığı aracılığıyla para transferi yetkilerinin (kendi hesapları arası işlemler hariç) meblağ, banka, finansal kuruluş ve konudan bağımsız tümüyle kaldırılması. Kararda bildirim zorunluluğu açıkça yazılmamıştır; ancak uygulamanın yapıldığını belgelemek yazışma güvencesi sağlar. Bu yazıyı kullanıcı istediğinde veya Kurum sorduğunda hazırla.

**Konu:** `İnternet Bankacılığı Para Transferi Yetkilerinin Kaldırılması Hk.`

**Gövde iskeleti:** çalışılan banka listesi, yetkinin kaldırıldığı tarih, kendi hesapları arası işlemlere izin verilen hesaplar, yeni ödeme yöntemi (ör. ıslak imzalı/yetkili talimatı). Ekler: bankalardan alınan yazılar/onaylar.

---

## 8. Düzeltme / ek bilgi yazısı

Daha önce gönderilen bir bildirimde hata veya eksiklik fark edilirse: Konu `... Bildirimine İlişkin Düzeltme (İlgi (b) Yazımız)`. İlgi (b): hatalı yazı (tarih/sayı). Gövdede neyin hatalı olduğu, doğru bilgi ve düzeltilmiş tablo yer alır. Kapanış: "Bilgilerinize ve gereğine arz ederiz."

---

## 9. Birleşik yazı (birden fazla işlem)

Kullanıcı birden fazla işlem saydığında:
- Onay talepleri (tür 4) **ayrı yazı** olur — Kurum cevabı ayrı takip edilir ve ödeme/imza bu cevaba bağlıdır.
- Hukuk günlük bildirimi (tür 5) **ayrı yazı** olur — günlük rutin, sabit format.
- Ödeme (1), YK kararı (2) ve dış hizmet (3) bildirimleri, aynı dönemdeyse tek yazıda numaralı alt başlıklarla birleştirilebilir.
- Birleşik yazının Konusu: `Yakın İzleme Kapsamında Bilgi Sunumu ([●dönem])`; gövdede her işlem için `{"baslik": "1. Ödeme Bilgileri"}` vb. alt başlık, Ekler sırayla numaralı ve gövdede "Ek-1", "Ek-2" olarak atıf alır.
- Kullanıcı ayrı yazı istiyorsa ayrı hazırla.
