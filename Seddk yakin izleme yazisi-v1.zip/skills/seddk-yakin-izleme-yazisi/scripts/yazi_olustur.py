#!/usr/bin/env python3
"""SEDDK'ya gönderilecek resmi yazıyı, şirketin mevcut yazı formatında .docx olarak üretir.

Biçim (kullanıcının Pert/Sovtaj ve İç Denetim Envanteri yazılarından alınmıştır):
Arial 12, A4, 2,5 cm kenar boşluğu; solda muhatap (3 satır, kalın), sağda Tarih ve Ref;
Konu / İlgi; iki yana yaslı, ilk satır girintili, 1,5 satır aralıklı gövde; ortalı
"Saygılarımızla," + şirket unvanı + yan yana iki imza; "Ek:" listesi.

Kullanım:
    python yazi_olustur.py girdi.json cikti.docx [--sirket sirket_bilgileri.json]

girdi.json (* zorunlu):
{
  "ref":    "2026/123",                 # şirket Ref numarası (yoksa [●] yer tutucusu)
  "tarih":  "30.09.2026",               # GG.AA.YYYY
  "konu":   "...",                      # *
  "ilgi":   ["...", "..."],             # * en az 1 (birden fazlaysa a), b) otomatik)
  "dikkat": "...",                      # opsiyonel, muhatabın altında italik satır
  "govde":  [ ... ],                    # *
  "ekler":  ["...", "..."],             # opsiyonel
  "imza":   [{"ad": "...", "unvan": "..."}, {...}]   # verilmezse şirket dosyasındaki varsayılan
}

govde öğeleri:
  "düz metin"                           -> iki yana yaslı paragraf (ilk satır girintili);
                                           "... arz ederiz." ile biten kısa cümle girintisiz kapanış olur
  {"baslik": "1. ..."}                  -> kalın alt başlık
  {"liste": ["...", "..."], "tip": "harf"|"rakam"|"madde"}
  {"tablo": {"basliklar": [...], "satirlar": [[...]], "genislikler_cm": [..],
             "sayi_sutunlari": [idx], "toplam_satiri": [...]}}
  {"not": "küçük punto açıklama"}

[●...] biçimindeki yer tutucular sarı vurgulanır; gönderimden önce doldurulmalıdır.
"""
import argparse
import json
import os
import re
import sys

from docx import Document
from docx.enum.section import WD_ORIENT
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_COLOR_INDEX, WD_TAB_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

FONT = "Arial"
PLACEHOLDER = re.compile(r"(\[●[^\]]*\])")


# ---------- yardımcılar ----------
def set_font(run, size=None, bold=None, italic=None, color=None):
    run.font.name = FONT
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.append(rfonts)
    for a in ("w:ascii", "w:hAnsi", "w:cs", "w:eastAsia"):
        rfonts.set(qn(a), FONT)
    if size:
        run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold
    if italic is not None:
        run.italic = italic
    if color:
        run.font.color.rgb = RGBColor.from_string(color)


def add_text(par, text, size=12, bold=False, italic=False, color=None):
    """Metni ekler; [●...] yer tutucularını sarı vurgular."""
    for part in PLACEHOLDER.split(text):
        if not part:
            continue
        r = par.add_run(part)
        set_font(r, size, bold, italic, color)
        if PLACEHOLDER.fullmatch(part):
            r.font.highlight_color = WD_COLOR_INDEX.YELLOW
    return par


def fmt(par, align=None, before=0, after=6, left=None, first=None, hanging=None,
        keep_next=False, line=1.35):
    pf = par.paragraph_format
    pf.space_before = Pt(before)
    pf.space_after = Pt(after)
    pf.line_spacing = line
    if align is not None:
        par.alignment = align
    if left is not None:
        pf.left_indent = Cm(left)
    if first is not None:
        pf.first_line_indent = Cm(first)
    if hanging is not None:
        pf.left_indent = Cm(hanging)
        pf.first_line_indent = Cm(-hanging)
    pf.keep_with_next = keep_next
    return par


def bottom_border(par, sz=8):
    ppr = par._p.get_or_add_pPr()
    borders = OxmlElement("w:pBdr")
    b = OxmlElement("w:bottom")
    b.set(qn("w:val"), "single")
    b.set(qn("w:sz"), str(sz))
    b.set(qn("w:space"), "4")
    b.set(qn("w:color"), "444444")
    borders.append(b)
    ppr.append(borders)


def shade(cell, hex_fill):
    tcpr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_fill)
    tcpr.append(shd)


def cell_margins(table, top=50, bottom=50, left=80, right=80):
    tblpr = table._tbl.tblPr
    mar = OxmlElement("w:tblCellMar")
    for k, v in (("top", top), ("left", left), ("bottom", bottom), ("right", right)):
        e = OxmlElement(f"w:{k}")
        e.set(qn("w:w"), str(v))
        e.set(qn("w:type"), "dxa")
        mar.append(e)
    tblpr.append(mar)


def no_split_row(row):
    trpr = row._tr.get_or_add_trPr()
    e = OxmlElement("w:cantSplit")
    trpr.append(e)


def repeat_header(row):
    trpr = row._tr.get_or_add_trPr()
    e = OxmlElement("w:tblHeader")
    trpr.append(e)


def add_field(par, instr, size=8):
    r = par.add_run()
    set_font(r, size)
    for t, txt in (("begin", None), (None, instr), ("end", None)):
        if t:
            fc = OxmlElement("w:fldChar")
            fc.set(qn("w:fldCharType"), t)
            r._r.append(fc)
        else:
            it = OxmlElement("w:instrText")
            it.set(qn("xml:space"), "preserve")
            it.text = txt
            r._r.append(it)


def no_borders(table):
    tblpr = table._tbl.tblPr
    borders = OxmlElement("w:tblBorders")
    for k in ("top", "left", "bottom", "right", "insideH", "insideV"):
        e = OxmlElement(f"w:{k}")
        e.set(qn("w:val"), "nil")
        borders.append(e)
    tblpr.append(borders)


def fixed_layout(table):
    tblpr = table._tbl.tblPr
    lay = OxmlElement("w:tblLayout")
    lay.set(qn("w:type"), "fixed")
    tblpr.append(lay)


# ---------- gövde öğeleri ----------
def render_liste(doc, item):
    tip = item.get("tip", "harf")
    for i, txt in enumerate(item["liste"]):
        if tip == "harf":
            mark = f"{chr(ord('a') + i)})"
        elif tip == "rakam":
            mark = f"{i + 1}."
        else:
            mark = "•"
        p = doc.add_paragraph()
        p.paragraph_format.tab_stops.add_tab_stop(Cm(2.0))
        add_text(p, f"{mark}\t{txt}")
        fmt(p, WD_ALIGN_PARAGRAPH.JUSTIFY, after=3, left=2.0, first=-0.75)


def render_tablo(doc, t, usable_cm):
    heads = t["basliklar"]
    rows = t["satirlar"]
    toplam = t.get("toplam_satiri")
    n = len(heads)
    widths = t.get("genislikler_cm")
    if not widths:
        widths = [usable_cm / n] * n
    scale = usable_cm / sum(widths)
    widths = [w * scale for w in widths]

    table = doc.add_table(rows=1, cols=n)
    table.style = "Table Grid"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    fixed_layout(table)
    cell_margins(table)
    for i, col in enumerate(table.columns):
        col.width = Cm(widths[i])

    def fill(row, values, bold=False, fill_hex=None, align_right_cols=()):
        for i, v in enumerate(values):
            c = row.cells[i]
            c.width = Cm(widths[i])
            p = c.paragraphs[0]
            add_text(p, str(v), size=10, bold=bold)
            fmt(p, WD_ALIGN_PARAGRAPH.RIGHT if i in align_right_cols else WD_ALIGN_PARAGRAPH.LEFT,
                after=0, line=1.0)
            if fill_hex:
                shade(c, fill_hex)

    money_cols = set(t.get("sayi_sutunlari", []))
    fill(table.rows[0], heads, bold=True, fill_hex="E7E6E6")
    repeat_header(table.rows[0])
    no_split_row(table.rows[0])
    for r in rows:
        row = table.add_row()
        no_split_row(row)
        fill(row, r, align_right_cols=money_cols)
    if toplam:
        row = table.add_row()
        no_split_row(row)
        fill(row, toplam, bold=True, fill_hex="F2F2F2", align_right_cols=money_cols)
    sp = doc.add_paragraph()
    fmt(sp, after=4)


# ---------- ana üretim ----------
KAPANIS = re.compile(r"arz ederiz\.$")


def build(data, sirket, out_path):
    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Cm(21.0), Cm(29.7)
    sec.orientation = WD_ORIENT.PORTRAIT
    sec.top_margin = sec.bottom_margin = Cm(2.5)
    sec.left_margin = sec.right_margin = Cm(2.5)
    usable = 16.0

    st = doc.styles["Normal"]
    st.font.name = FONT
    st.font.size = Pt(12)

    # Antetli kağıt payı
    sp = doc.add_paragraph()
    fmt(sp, after=0, line=1.0)
    sp.paragraph_format.space_before = Pt(sirket.get("ust_bosluk_pt", 40))

    # Muhatap (sol) + Tarih/Ref (sağ)
    hdr = doc.add_table(rows=1, cols=2)
    no_borders(hdr)
    hdr.autofit = False
    fixed_layout(hdr)
    widths = (11.0, 5.0)
    for i, c in enumerate(hdr.rows[0].cells):
        c.width = Cm(widths[i])
    hdr.columns[0].width, hdr.columns[1].width = Cm(widths[0]), Cm(widths[1])
    left, right = hdr.rows[0].cells
    first = True
    for line in sirket["muhatap_satirlari"]:
        p = left.paragraphs[0] if first else left.add_paragraph()
        first = False
        add_text(p, line, bold=True)
        fmt(p, WD_ALIGN_PARAGRAPH.LEFT, after=0, line=1.15)
    p = right.paragraphs[0]
    add_text(p, "Tarih: " + data.get("tarih", "[●GG.AA.YYYY]"), bold=True)
    fmt(p, WD_ALIGN_PARAGRAPH.LEFT, after=0, line=1.15)
    p = right.add_paragraph()
    add_text(p, "Ref: " + data.get("ref", "[●YYYY/NNN]"), bold=True)
    fmt(p, WD_ALIGN_PARAGRAPH.LEFT, after=0, line=1.15)

    if data.get("dikkat"):
        p = doc.add_paragraph()
        add_text(p, f"Dikkat: {data['dikkat']}", size=11, italic=True)
        fmt(p, WD_ALIGN_PARAGRAPH.LEFT, before=6, after=0, line=1.15)

    sp = doc.add_paragraph()
    fmt(sp, after=0, line=1.0)

    # Konu
    p = doc.add_paragraph()
    p.paragraph_format.tab_stops.add_tab_stop(Cm(1.5))
    add_text(p, "Konu\t", bold=True)
    add_text(p, ": " + data["konu"])
    fmt(p, WD_ALIGN_PARAGRAPH.LEFT, after=2, hanging=1.5, line=1.15)

    # İlgi
    ilgi = data["ilgi"]
    ind = 1.5 + (0.5 if len(ilgi) > 1 else 0)
    for i, txt in enumerate(ilgi):
        p = doc.add_paragraph()
        p.paragraph_format.tab_stops.add_tab_stop(Cm(1.5))
        if i == 0:
            add_text(p, "İlgi\t", bold=True)
            add_text(p, ": ")
        else:
            add_text(p, "\t  ")
        if len(ilgi) > 1:
            add_text(p, f"{chr(ord('a') + i)}) ")
        add_text(p, txt)
        fmt(p, WD_ALIGN_PARAGRAPH.JUSTIFY, after=2, left=ind, first=-ind, line=1.15)

    sp = doc.add_paragraph()
    fmt(sp, after=0, line=1.0)

    # Gövde
    for item in data["govde"]:
        if isinstance(item, str):
            p = doc.add_paragraph()
            add_text(p, item)
            if KAPANIS.search(item) and len(item) < 70:
                fmt(p, WD_ALIGN_PARAGRAPH.LEFT, before=6, after=6, keep_next=True)
            else:
                fmt(p, WD_ALIGN_PARAGRAPH.JUSTIFY, after=4, first=1.25)
        elif "baslik" in item:
            p = doc.add_paragraph()
            add_text(p, item["baslik"], bold=True)
            fmt(p, WD_ALIGN_PARAGRAPH.LEFT, before=4, after=4, keep_next=True)
        elif "liste" in item:
            render_liste(doc, item)
            sp = doc.add_paragraph()
            fmt(sp, after=2, line=1.0)
        elif "tablo" in item:
            render_tablo(doc, item["tablo"], usable)
        elif "not" in item:
            p = doc.add_paragraph()
            add_text(p, item["not"], size=10, italic=True)
            fmt(p, WD_ALIGN_PARAGRAPH.JUSTIFY, after=8, line=1.15)

    # Saygılarımızla + şirket unvanı
    p = doc.add_paragraph()
    add_text(p, "Saygılarımızla,")
    fmt(p, WD_ALIGN_PARAGRAPH.CENTER, before=10, after=0, keep_next=True, line=1.15)
    p = doc.add_paragraph()
    add_text(p, sirket["sirket_adi_kisa"], bold=True)
    fmt(p, WD_ALIGN_PARAGRAPH.CENTER, after=30, keep_next=True, line=1.15)

    # İmzalar (yan yana)
    imzalar = data.get("imza") or sirket["varsayilan_imzacilar"]
    sig = doc.add_table(rows=1, cols=len(imzalar))
    sig.alignment = WD_TABLE_ALIGNMENT.CENTER
    sig.autofit = False
    no_borders(sig)
    fixed_layout(sig)
    no_split_row(sig.rows[0])
    w = usable / len(imzalar)
    for i, col in enumerate(sig.columns):
        col.width = Cm(w)
    for i, sg in enumerate(imzalar):
        c = sig.rows[0].cells[i]
        c.width = Cm(w)
        p = c.paragraphs[0]
        add_text(p, sg["ad"], bold=True)
        fmt(p, WD_ALIGN_PARAGRAPH.CENTER, after=0, keep_next=True, line=1.15)
        p = c.add_paragraph()
        add_text(p, sg["unvan"])
        fmt(p, WD_ALIGN_PARAGRAPH.CENTER, after=0, line=1.15)

    # Ekler
    ekler = data.get("ekler") or []
    if ekler:
        sp = doc.add_paragraph()
        fmt(sp, after=14, line=1.0)
        p = doc.add_paragraph()
        r = p.add_run("Ek:")
        set_font(r, 12, bold=True)
        r.underline = True
        fmt(p, WD_ALIGN_PARAGRAPH.LEFT, after=0, keep_next=True, line=1.15)
        for i, e in enumerate(ekler):
            p = doc.add_paragraph()
            add_text(p, f"- {e}")
            fmt(p, WD_ALIGN_PARAGRAPH.LEFT, after=0, hanging=0.5,
                keep_next=(i < len(ekler) - 1), line=1.15)

    # Boş ayırıcı paragrafları kısalt (tek sayfaya sığma)
    for par in doc.paragraphs[1:]:
        if not par.text.strip() and not par.runs:
            par.paragraph_format.line_spacing = Pt(7)
            par.paragraph_format.space_after = Pt(0)

    doc.save(out_path)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("girdi")
    ap.add_argument("cikti")
    default_cfg = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..",
                               "assets", "sirket_bilgileri.json")
    ap.add_argument("--sirket", default=default_cfg)
    a = ap.parse_args()
    with open(a.girdi, encoding="utf-8") as f:
        data = json.load(f)
    with open(a.sirket, encoding="utf-8") as f:
        sirket = json.load(f)
    for k in ("konu", "ilgi", "govde"):
        if not data.get(k):
            sys.exit(f"Eksik alan: {k}")
    build(data, sirket, a.cikti)
    left = []
    blob = json.dumps(data, ensure_ascii=False) + json.dumps(sirket, ensure_ascii=False)
    left = sorted(set(PLACEHOLDER.findall(blob)))
    print(f"Yazı üretildi: {a.cikti}")
    if left:
        print("Doldurulması gereken yer tutucular:")
        for x in left:
            print("  ", x)


if __name__ == "__main__":
    main()
