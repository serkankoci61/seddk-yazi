---
name: seddk-yakin-izleme-yazisi
description: DOGA Sigorta A.Ş.'nin SEDDK'nın 23.09.2026 tarih ve 1937 sayılı Kurul Kararı (yakın izleme) kapsamında Kuruma göndereceği resmi yazıları hazırlar. Kullanıcı şu işlemlerden birini veya birkaçını belirttiğinde MUTLAKA kullan — ana faaliyet dışı 100 bin TL üzeri ödeme bildirimi, yönetim kurulu kararı bildirimi, dış hizmet alımı bildirimi, 500.000 TL üzeri sözleşme için Kurum onayı talebi, hukuk dosyası ödemelerinin günlük bildirimi, 20.000.000 TL serbest tutar/hesap bildirimi, internet bankacılığı yetki kaldırma bildirimi, düzeltme/ek bilgi yazısı, periyodik durum özeti. "SEDDK'ya yazı", "Kuruma bildirim", "yakın izleme yazısı", "Kurum onayı yazısı", "hukuk ödemesi bildirimi", "düzeltme yazısı" gibi ifadelerde de tetiklenir. Çıktı, Konu/İlgi/Açıklama/Ek yapısına sahip, iki imzalı (Serkan KOÇ - Müdür, Kuntay BAYDAR) Word (.docx) yazıdır.
---

# SEDDK Yakın İzleme Yazısı Hazırlama

SEDDK, Şirketi 23.09.2026 tarih ve 1937 sayılı Kurul Kararı ile yakın izleme kapsamına almıştır. Bu skill, karardan doğan bildirim ve onay yazılarını tutarlı biçimde hazırlar. Resmi yazışmada tek bir eksik (yanlış İlgi, eksik ek, yanlış eşik) Kurumun geri dönüşüne veya yanlış bir uyum beyanına yol açabildiği için, yazıyı yazmadan önce kapsam kontrollerini yap, veri uydurma, eksikleri açıkça işaretle.

## Kararın dört maddesi (yazıların dayanağı)

| # | Karar | Yazı türü |
|---|---|---|
| 1 | Ana faaliyet dışı (komisyon, hasar, reasürans, maaş, vergi ve diğer yasal yükümlülükler hariç) **100 bin TL üzeri** ödemeler, **yönetim kurulu kararları** ve **dış hizmet alımları** Kuruma gönderilecek | 1 Ödeme, 2 YK kararı, 3 Dış hizmet |
| 2 | Ana faaliyet dışı, yükümlülük doğuran ve **500.000 TL üzerindeki** tüm sözleşmeler **Kurum onayına** tabi | 4 Sözleşme onay talebi |
| 3 | İnternet bankacılığıyla para transferi yetkisi (kendi hesapları arası hariç) tümüyle kaldırıldı | 7 Uygulama bildirimi (isteğe bağlı) |
| 4 | Hukuk dosyası ödemeleri **günlük** bildirilecek; şirketçe belirlenecek hesapta tutulan **20.000.000 TL** bloke tutar serbest, yalnızca hukuk dosyalarında kullanılacak | 5 Günlük bildirim, 6 Hesap bildirimi |

Ek türler (karar dışı ama sık ihtiyaç): **8 Düzeltme/ek bilgi**, **9 Periyodik durum özeti**.

Her türün gövde iskeleti, Konu kalıbı, toplanacak bilgiler ve ekleri `references/sablonlar.md` içindedir. Yazıya başlamadan o dosyada ilgili türü oku. Örnek girdi JSON'ları `references/ornekler/` altındadır.

## İş akışı

1. **Türü belirle.** Kullanıcının saydığı işlemleri yukarıdaki türlere eşle. Birden fazla işlem varsa `sablonlar.md` bölüm 10'daki birleştirme kuralını uygula (onay talepleri, hukuk günlük bildirimi ve düzeltme her zaman ayrı yazı).
2. **Kapsam kontrolü yap** (aşağıdaki liste). Kontrol yazının hiç gerekmediğini gösterirse (ör. tamamı maaş/vergi) bunu söyle ve yazı hazırlama.
3. **Eksik bilgileri tek seferde sor**, yalnızca yazıyı anlamlı kılmak için şart olanları (tutar, karşı taraf, tarih, dönem). Kullanıcı bilgileri verdiyse sorma. Bilinmeyen ikincil bilgiler için `[●açıklama]` yer tutucusu bırak; script bunları sarı vurgular.
4. **Yazıyı kur**: girdi JSON'unu oluştur, scripti çalıştır (aşağıda). Örnek JSON'ları `references/ornekler/` içinden kopyalayıp uyarlayabilirsin.
5. **Görsel kontrol**: docx'i PDF'e çevirip sayfa görüntüsüne bak (docx skill "Verify the output"), taşma, bölünmüş tablo satırı, yalnız kalan imza bloğu var mı kontrol et.
6. **Teslim**: dosyayı uygun çıktı dizinine koy. Yanıtta kısa bir özet ver (aşağıdaki "Teslim notu").

## Zorunlu yazı yapısı

Biçim, kullanıcının daha önce Kuruma gönderdiği yazılardan (Pert/Sovtaj iç denetim üst yazısı, İç Denetim Envanteri eksik evrak yazısı) alınmıştır; script bunu üretir. Her yazı şu sırayı izler:

1. **Muhatap (solda, kalın, 3 satır):** SİGORTACILIK VE ÖZEL EMEKLİLİK / DÜZENLEME VE DENETLEME KURUMU / İSTANBUL. Sağda kalın **Tarih: GG.AA.YYYY** ve **Ref: YYYY/NNN** (şirket giden evrak numarası; kullanıcı vermediyse `[●YYYY/NNN]` kalır). Şirket antetli kâğıt kullandığı için sayfada ayrıca antet basılmaz, üstte boşluk bırakılır.
2. **Konu:** tek cümlelik, işlemi ve (varsa) dönemi/karşı tarafı adlandıran başlık.
3. **İlgi:** en az bir satır. (a) her zaman SEDDK'nın E-97354901-045.01-5033535 sayılı yazısı ve 1937 sayılı Kurul Kararı (`assets/sirket_bilgileri.json` → `ana_ilgi`). Sonraki harfler ilgili önceki yazışmalar (önceki bildirim, Kurum onayı, YK kararı). Birden fazla ilgi a), b), c) diye harflenir; gövdede "İlgi (a) yazınız" biçiminde atıf yapılır.
4. **Açıklama (gövde):** iki yana yaslı, ilk satır girintili. İlk paragrafta yazının **ne amaçla gönderildiği** açıkça yazılır ("... bilgi verilmesi amaçlanmaktadır", "... onayınız talep edilmektedir"). Ardından ayrıntı/tablo ve beyan gelir; en sonda girintisiz, tek satırlık kapanış: "Bilgilerinize arz ederiz." / "Gereğini ve onayınızı arz ederiz." / "Bilgilerinize ve gereğine arz ederiz."
5. **Saygılarımızla, / DOGA SİGORTA A.Ş.** (ortalı) ve altında **iki imza yan yana**: sol **Serkan KOÇ – Müdür**, sağ **Kuntay BAYDAR – Genel Müdür Yardımcısı**. Kullanıcı farklı imzacı isterse (geçmiş yazılarda Coşkun GÖLPINAR – Genel Müdür, Fehmi ÖZBALKAN – Genel Müdür Yardımcısı da imzalamıştır) JSON'daki `imza` alanıyla geçersiz kıl; aksi halde yukarıdaki iki imzacıyı kullan. Script imza alanı için dikey boşluk bırakır.
6. **Ek:** ek varsa imzanın altında kalın-altı çizili `Ek:` başlığı ve her satırda `- ...` biçiminde liste; gövdede de atıf bulunur ("ekte sunulmaktadır", "Ek-1"). Ek yoksa Ek bölümü ve "ekte" ifadesi olmaz. Gövdede atıf yapılan her ek listede, listedeki her ek gövdede geçmelidir; sayfa sayısı biliniyorsa yaz.

Dil ve biçim: resmî, kısa, edilgen-nötr üslup ("arz ederiz", "rica ederiz"); Şirket "Şirketimiz", Kurum "Kurumunuz". Tutarlar `1.250.000,00 TL`; önemli tutarlarda rakam yanında yazıyla ("1.250.000,00 TL (birmilyonikiyüzellibin Türk Lirası)"). Tarih GG.AA.YYYY (nokta ayraçlı). Kurum adı ilk geçtiği yerde tam yazılır. Kararın olmadığı bir yükümlülüğü, süreyi veya yorumu Kurumun kararıymış gibi yazma.

## Kapsam ve tutarlılık kontrolleri (yazıdan önce)

**Ödeme bildirimi (tür 1)**
- Ödeme ana faaliyet kapsamında mı? Komisyon (acente/broker dahil), hasar, reasürans, maaş, vergi ve diğer yasal yükümlülükler (SGK, zorunlu Kurum/Hazine katkıları vb.) **hariç**. Gri kalan kalemlerde (örn. sektör kuruluşu aidatları, avukatlık ücreti, bağış/sponsorluk) karar verme; kullanıcıya ya da uyum birimine sor, varsayılan olarak bildirime dahil et ve bunu belirt.
- "100 bin TL üzeri" = 100.000 TL'yi **aşan**; eşit olan kapsam dışıdır. Döviz ödemede TL karşılığını, kurunu ve kur tarihini yaz. KDV dahil/hariç olduğunu belirt; emin değilsen kullanıcıya sor (muhafazakâr varsayım: KDV dahil).
- Bölünmüş ödeme: aynı alıcıya aynı işten dolayı parçalanmış ödemeler eşiği aşıyorsa kullanıcıyı uyar; toplamı aşıyorsa bildirime dahil edilmesini öner.
- Hukuk dosyası ödemelerini aylık/dönemsel ödeme tablosuna koyma; günlük rejim (tür 5) uygular. Gövdede atıf yap.
- Bildirimin ödemeden **önce** mi **sonra** mı yapılacağı kararda açık değil; kullanıcı belirtmediyse sor, cevap yoksa "ödeme sonrası" varsay ve bunu teslim notunda işaretle. Kurum periyot belirtmişse (haftalık/aylık) Konu ve İlgi'de ona atıf yap.
- İnternet bankacılığından para transferi yapılamadığı için (md. 3) ödeme kanalı sütununu boş bırakma; kullanıcı ödemenin hangi yöntemle yapıldığını söylemeli.

**Sözleşme onayı (tür 4)**
- Üç şart birlikte aranır: ana faaliyet dışı + yükümlülük doğurur + tutar > 500.000 TL. Sözleşme **toplam bedeli** (tüm süre, tüm taksitler) esas alınır; yıllık bedel eşiğin altında kalsa da toplam aşıyorsa onay gerekir.
- Ek protokol, süre uzatımı, yenileme, bedel artışı ve aynı tedarikçiyle birbirine bağlı çerçeve/sipariş sözleşmeleri eşiği aşıyorsa uyar.
- Onay **imzadan önce** alınmalı: yazıda "onay alınmadan imzalanmayacak/yürürlüğe girmeyecek" taahhüdü bulunmalı. Sözleşme zaten imzalıysa yazıyı bu durumu dürüstçe yansıtacak şekilde kur (onay talebi değil, gerekçeli bilgi/onay yazısı) ve kullanıcıyı uyar.
- Onaydan sonra yapılacak 100.000 TL üzeri ödemeler ayrıca tür 1 ile bildirilir.

**Yönetim kurulu kararı (tür 2)**: Karar metni "yönetim kurulu kararları" diyor; ayrım yapılmadığı için tüm YK kararları bildirilmiş sayılır, kullanıcı aksini teyit edince daralt. Karar tarih/sayısı ve özeti ek sureti ile birebir uyumlu olmalı.

**Dış hizmet alımı (tür 3)**: Hizmet sağlayıcı, kapsam, süre, bedel, kritik faaliyet olup olmadığı, risk değerlendirmesi gibi alanlar eksiksiz olmalı. Bedel > 500.000 TL ve ana faaliyet dışıysa onay yazısı (tür 4) de gerekir.

**Hukuk günlük bildirimi (tür 5/6)**: Tablodaki ödeme toplamı bakiye tablosuyla tutarlı olmalı (kalan = 20.000.000 − önceki kümülatif − günün toplamı). Hesap bildirimi (tür 6) ilk günlük bildirimden önce gönderilmiş olmalı; kullanıcı göndermediyse hatırlat. Ödeme yapılmayan günlerde "ödeme yoktur" bildirimi gerekip gerekmediği kararda belli değil; kullanıcıya sor, belirtmediyse yalnızca ödeme olan günlerde yazı hazırla ve teslim notunda işaretle. Gerçek kişilere ait kimlik/IBAN bilgisini gövdeye yazma (KVKK, asgari veri).

**Düzeltme (tür 8)**: Hatalı yazının tarih ve Ref/sayısını İlgi (b) olarak doğru taşı; eski→yeni karşılaştırmayı net yaz.

**Genel**
- Rakamları kaynaktan iki kez kontrol et; toplamları hesapla, tahmin etme.
- Yabancı tutar/tarih/sayı eksikse uydurma, yer tutucu bırak.
- Ekte kişisel veri veya ticari sır varsa kullanıcıya maskeleme/gizlilik notu ekleme önerisi yap.
- Yazı e-imzayla ve resmi kanaldan (KEP/EBYS) gider; ekleri PDF olarak hazırlamayı öner, dosya adlarını ek sırasıyla ver.
- Kurumun verdiği bir süre varsa (Konu/İlgi'de atıf) tarih karşılaştır; süre geçmişse gecikme gerekçesini tek cümleyle yazmayı öner.
- Gelen yazıya cevap niteliğindeki yazılarda Kurum yazısının sayı/tarihini İlgi'ye doğru taşı.

## Script kullanımı

```bash
python scripts/yazi_olustur.py girdi.json /path/to/cikti.docx
python scripts/yazi_olustur.py girdi.json /path/to/cikti.docx --validate-only   # sadece doğrula
```

Script yolu: skill dizinindeki `scripts/yazi_olustur.py`. Şirket bilgileri varsayılan olarak `assets/sirket_bilgileri.json` okunur (`--sirket` ile değiştirilebilir).

**Girdi doğrulama:** Script zorunlu alanları, tarih formatını (GG.AA.YYYY), tablo sütun uyumunu ve imza yapısını kontrol eder; hata varsa çıkış kodu 1 ile durur. Yer tutucular (`[●...]`) listelenir.

**Tablo iyileştirmeleri:** Başlık satırı mavi-gri, toplam satırı sarımsı vurgu; dar sütunlarda 9 pt font; satır bölünmez; dikey ortala.

**İmza bloğu:** Ad/unvan üstünde ıslak/e-imza için dikey boşluk bırakılır.

## Teslim notu (yanıtta kısaca yaz)

- Yazı türü ve Konu
- Ref ve tarih (veya yer tutucu)
- Tablo/toplam özeti (varsa)
- Eksik yer tutucular
- Ek listesi
- Varsa uyarı (kapsam gri alan, onay henüz alınmamış sözleşme, hesap bildirimi eksik vb.)

## Kaynaklar

- `references/sablonlar.md` — tüm tür şablonları ve dil notları
- `references/ornekler/` — hazır girdi JSON örnekleri (01 ödeme, 04 onay, 05 hukuk, 06 hesap, 08 düzeltme)
- `assets/sirket_bilgileri.json` — muhatap, ana_ilgi, varsayılan imzacılar
- `scripts/yazi_olustur.py` — docx üretici
