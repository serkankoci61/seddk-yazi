# Yazı Türleri, Şablonlar ve Zorunlu Bilgiler

Her tür için: Konu kalıbı, İlgi, gövde iskeleti, toplanacak bilgiler, tipik ekler.
`[●...]` yer tutucuları kullanıcıdan gelmeyen bilgiler içindir; uydurma veri yazma.

Ortak giriş paragrafı (her yazıda ilk paragraf; tür cümlesi sonda eklenir):
> İlgi (a) yazınız ile Sigortacılık ve Özel Emeklilik Düzenleme ve Denetleme Kurulu'nun 23.09.2026 tarih ve 1937 sayılı Kararı uyarınca Şirketimizin yakın izleme kapsamına alındığı bildirilmiştir.

Ortak kapanış cümleleri:
- Bildirim/bilgi yazıları: "Bilgilerinize arz ederiz."
- Onay/talep yazıları: "Gereğini ve onayınızı arz ederiz."
- Düzeltme/ek bilgi: "Bilgilerinize ve gereğine arz ederiz."

---

## 1. Ödeme bildirimi (ana faaliyet dışı, 100.000 TL üzeri)

**Kapsam:** 1937 sayılı Karar md. 1 — komisyon, hasar, reasürans, maaş, vergi ve diğer yasal yükümlülükler dışındaki, tek tek 100.000 TL'yi aşan ödemeler.

**Konu:** `Yakın İzleme Kapsamında Ödeme Bilgilendirmesi ([●başlangıç] – [●bitiş] Dönemi)` (tek ödeme ise: `Yakın İzleme Kapsamında Ödeme Bilgilendirmesi ([●alıcı unvanı])`)

**İlgi:** (a) ana_ilgi.

**Gövde iskeleti:**
1. Ortak giriş + "Anılan Karar kapsamında, ana sigortacılık faaliyeti dışında kalan ve 100.000 TL'yi aşan ödemelere ilişkin bilgiler, [●dönem] dönemi için aşağıdaki tabloda ve Ek'te sunulmuştur."
2. Tablo: Sıra | Ödeme Tarihi | Alıcı Unvanı | Ödeme Nedeni (fatura/sözleşme no) | Tutar (TL) | Ödeme Kanalı/Banka | Dayanak (YK kararı / Kurum onayı)
3. Toplam satırı.
4. Beyan: "Tabloda yer alan ödemeler komisyon, hasar, reasürans, maaş, vergi ve diğer yasal yükümlülük niteliğinde değildir; hukuk dosyaları kapsamındaki ödemeler ise ayrıca günlük olarak bildirilmektedir."
5. Kapanış: "Bilgilerinize arz ederiz."

**Toplanacak bilgiler:** ödeme tarihi, alıcı, neden, tutar (KDV dahil/hariç belirtilerek), para birimi ve kur, ödeme kanalı, dayanak belge, ilgili sözleşme/YK kararı/Kurum onay yazısı tarih-sayısı.
**Tipik ekler:** ödeme dekontları, fatura suretleri, (varsa) sözleşme ve onay yazısı, ödeme listesi (Excel).

---

## 2. Yönetim kurulu kararı bildirimi

**Konu:** `Yakın İzleme Kapsamında Yönetim Kurulu Kararının Bildirilmesi ([●karar tarihi] Tarih ve [●karar no] Sayılı Karar)`

**Gövde iskeleti:**
1. Ortak giriş + "Anılan Karar uyarınca Şirketimiz Yönetim Kurulu'nun [●GG.AA.YYYY] tarih ve [●no] sayılı kararının sureti yakın izleme kapsamında ilişikte sunulmuştur."
2. Kısa karar özeti (konu, alınan karar, varsa tutar/yükümlülük, uygulama tarihi). Özet, kararın içeriğini değiştirmemeli; bire bir ek surete atıf yapılmalı.
3. Kararın Kurum onayına tabi bir işlem içerip içermediği (ör. >500.000 TL sözleşme) — içeriyorsa ayrı onay yazısına atıf.
4. Kapanış: "Bilgilerinize arz ederiz."

**Not:** Kararda "yönetim kurulu kararları" ifadesi kapsam bakımından geniş okunabilir; kullanıcı aksini teyit etmedikçe tüm YK kararlarının bildirildiği varsayılır. Bu varsayımı kullanıcıya hatırlat.
**Tipik ekler:** YK kararı (imzalı/onaylı suret veya e-imzalı örnek), varsa karara dayanak sunum/rapor.

---

## 3. Dış hizmet alımı bildirimi

**Konu:** `Yakın İzleme Kapsamında Dış Hizmet Alımı Bilgilendirmesi ([●hizmet sağlayıcı unvanı])`

**Gövde iskeleti:**
1. Ortak giriş + "Anılan Karar kapsamında, aşağıda bilgileri yer alan dış hizmet alımı hakkında Kurumunuza bilgi verilmesi amaçlanmaktadır."
2. Bilgi tablosu (iki sütun: Başlık | Bilgi): Hizmet sağlayıcı unvanı / vergi no / adres; hizmetin konusu ve kapsamı; hizmetin Şirket faaliyetlerindeki yeri (kritik/önemli mi); sözleşme tarihi ve süresi; bedel (KDV durumu, ödeme planı); alım gerekçesi; yetkili onayı (YK kararı/yetki dokümanı); risk/uyum değerlendirmesi özeti; varsa ilişkili taraf durumu.
3. Bedel 500.000 TL'yi aşıyor ve hizmet ana faaliyet dışıysa: "Sözleşme bedeli 500.000 TL'yi aştığından Kurum onayı için ayrıca [●tarih/sayı] yazımızla başvurulmuştur" (bu durumda tür 4 de hazırlanmalı; sözleşme imzadan önce onaya gitmelidir).
4. Kapanış: "Bilgilerinize arz ederiz."

**Tipik ekler:** sözleşme/teklif, hizmet seviyesi (SLA) dokümanı, risk değerlendirme formu, YK/yetki kararı.

---

## 4. Sözleşme onay talebi (ana faaliyet dışı, 500.000 TL üzeri)

**Kapsam:** 1937 sayılı Karar md. 2 — yükümlülük doğuran ve tutarı 500.000 TL'yi aşan tüm sözleşmeler Kurum onayına tabidir. Onay, sözleşme imzalanmadan önce alınmalıdır.

**Konu:** `500.000 TL Üzerindeki Sözleşmeye İlişkin Kurum Onayı Talebi ([●sözleşme konusu] – [●karşı taraf unvanı])`

**Gövde iskeleti:**
1. Ortak giriş + "Anılan Karar uyarınca, sigortacılık ana faaliyeti dışında yükümlülük doğuran ve tutarı 500.000 TL'yi aşan sözleşmeler Kurumunuzun onayına tabi tutulmuştur. Bu çerçevede aşağıda özeti sunulan sözleşme için onayınız talep edilmektedir."
2. Özet tablo veya madde: karşı taraf, konu, süre, toplam bedel (KDV durumu), ödeme planı, gerekçe, YK/yetki kararı, risk değerlendirmesi.
3. Taahhüt: "Söz konusu sözleşme, Kurumunuzun onayı alınmadan imzalanmayacak ve yürürlüğe girmeyecektir."
4. Kapanış: "Gereğini ve onayınızı arz ederiz."

**Toplanacak bilgiler:** karşı taraf unvan/VKN, sözleşme konusu, taslak metin, toplam bedel, süre, ödeme planı, YK kararı tarih/no, risk değerlendirmesi.
**Tipik ekler:** sözleşme taslağı, teklif, YK kararı, risk/uyum formu, fiyat karşılaştırması.

---

## 5. Hukuk dosyası ödemelerinin günlük bildirimi

**Kapsam:** 1937 sayılı Karar md. 4 — hukuk dosyası ödemeleri günlük bildirilir; 20.000.000 TL serbest tutar yalnızca bu amaçla kullanılır.

**Konu:** `Hukuk Dosyası Ödemelerine İlişkin Günlük Bildirim ([●GG.AA.YYYY] Tarihi)`

**Gövde iskeleti:**
1. Ortak giriş + "Anılan Karar uyarınca [●tarih] tarihinde hukuk dosyaları kapsamında yapılan ödemeler aşağıda tablo halinde sunulmuştur."
2. Tablo: Sıra | Dosya No / Mahkeme | Alıcı (avukat/alacaklı) | Ödeme Nedeni | Tutar (TL) | Ödeme Kanalı
3. Toplam; bakiye: "Serbest tutardan gün başı bakiye: [●] TL; günün ödemeleri: [●] TL; gün sonu kalan: [●] TL."
4. Ödeme yoksa: "Anılan tarihte hukuk dosyası kapsamında ödeme yapılmamıştır." (yalnızca kullanıcı isterse)
5. Kapanış: "Bilgilerinize arz ederiz."

**Not:** Gerçek kişi kimlik/IBAN bilgisi gövdeye yazılmaz (KVKK). Hesap bildirimi (tür 6) önceden gönderilmiş olmalıdır.
**Tipik ekler:** ödeme dekontları, mahkeme/avukat yazısı (gerektiğinde).

---

## 6. 20.000.000 TL serbest tutar / hesap bildirimi

**Kapsam:** Karar md. 4 — "şirketiniz tarafından belirlenecek hesapta" tutulacak. Hesap belirlendiğinde ve değiştiğinde Kuruma bildirilmelidir.

**Konu:** `Hukuk Dosyası Ödemelerine İlişkin Hesap Bildirimi ve Serbest Tutar Kullanım Taahhüdü`

**Gövde iskeleti:**
1. Ortak giriş + "Anılan Karar'ın ilgili maddesi uyarınca serbest bırakılacak 20.000.000 TL'lik tutarın tutulacağı hesap aşağıda bildirilmiştir."
2. Tablo: Banka | Şube | Hesap Adı | IBAN | Para Birimi | Serbest Tutar.
3. Taahhüt: "Söz konusu tutar yalnızca hukuk dosyaları kapsamındaki ödemelerde kullanılacak, ödemeler günlük olarak Kurumunuza bildirilecektir."
4. Kapanış: "Bilgilerinize arz ederiz."

**Tipik ekler:** bankadan hesap/bloke durumu yazısı (varsa).

---

## 7. İnternet bankacılığı yetki kaldırma uygulaması bildirimi (isteğe bağlı)

**Kapsam:** 1937 sayılı Karar md. 3 — Şirketin internet bankacılığı aracılığıyla para transferi yetkilerinin (kendi hesapları arası işlemler hariç) meblağ, banka, finansal kuruluş ve konudan bağımsız tümüyle kaldırılması. Kararda bildirim zorunluluğu açıkça yazılmamıştır; ancak uygulamanın yapıldığını belgelemek yazışma güvencesi sağlar.

**Konu:** `İnternet Bankacılığı Para Transferi Yetkilerinin Kaldırılması Hk.`

**Gövde iskeleti:**
1. Ortak giriş + "Anılan Karar'ın 3 üncü maddesi uyarınca internet bankacılığı aracılığıyla para transferi yetkilerinin kaldırılmasına ilişkin yapılan işlemler aşağıda özetlenmiştir."
2. Tablo veya liste: Banka adı | Yetki kaldırma tarihi | Kendi hesapları arası işlem izni (varsa hesaplar) | Yeni ödeme yöntemi.
3. Kapanış: "Bilgilerinize arz ederiz."

**Tipik ekler:** bankalardan alınan yetki kaldırma onay yazıları.

---

## 8. Düzeltme / ek bilgi yazısı

Daha önce gönderilen bir bildirimde hata veya eksiklik fark edilirse kullanılır.

**Konu:** `[●önceki yazı konusu] Bildirimine İlişkin Düzeltme (İlgi (b) Yazımız)` veya `... Ek Bilgi Sunumu`

**İlgi:** (a) ana_ilgi; (b) düzeltilen önceki yazı (tarih ve Ref/sayı).

**Gövde iskeleti:**
1. Ortak giriş + "İlgi (b) yazımızla sunulan [●konu] bildiriminde [●hata/eksiklik] tespit edilmiş olup, doğru bilgiler aşağıda sunulmaktadır."
2. Düzeltme tablosu veya madde listesi (eski → yeni).
3. Gerekirse güncellenmiş ekler.
4. Kapanış: "Bilgilerinize ve gereğine arz ederiz."

**Tipik ekler:** düzeltilmiş tablo/liste, ilgili belgeler.

---

## 9. Periyodik özet / durum raporu (isteğe bağlı)

Kurum talep ettiğinde veya şirket kendi inisiyatifiyle dönemsel durum özeti sunmak istediğinde.

**Konu:** `Yakın İzleme Kapsamında [●dönem] Dönemi Durum Özeti`

**Gövde iskeleti:**
1. Ortak giriş + "Anılan Karar kapsamında [●dönem] döneminde gerçekleştirilen bildirim ve işlemlerin özeti aşağıda sunulmuştur."
2. Özet tablo: Bildirim türü | Adet | Toplam tutar (varsa) | Açıklama.
3. Önemli gelişmeler (onay bekleyen sözleşmeler, hesap bakiyesi, YK kararları özeti).
4. Kapanış: "Bilgilerinize arz ederiz."

**Tipik ekler:** dönemsel özet Excel, önceki yazı listesi.

---

## 10. Birleşik yazı (birden fazla işlem)

Kullanıcı birden fazla işlem saydığında:
- Onay talepleri (tür 4) **ayrı yazı** olur — Kurum cevabı ayrı takip edilir.
- Hukuk günlük bildirimi (tür 5) **ayrı yazı** olur — günlük rutin, sabit format.
- Düzeltme (tür 8) genelde ayrı yazı olur.
- Ödeme (1), YK kararı (2) ve dış hizmet (3) bildirimleri, aynı dönemdeyse tek yazıda numaralı alt başlıklarla birleştirilebilir.
- Birleşik yazının Konusu: `Yakın İzleme Kapsamında Bilgi Sunumu ([●dönem])`; gövdede her işlem için `{"baslik": "1. Ödeme Bilgileri"}` vb. alt başlık; Ekler sırayla numaralı ve gövdede "Ek-1", "Ek-2" olarak atıf alır.
- Kullanıcı ayrı yazı istiyorsa ayrı hazırla.

---

## Dil ve üslup notları (gerçek yazışmaya yakınlık)

- Resmî, kısa, edilgen-nötr: "arz ederiz", "rica ederiz", "sunulmuştur", "bildirilmiştir".
- Şirket = "Şirketimiz"; Kurum = "Kurumunuz".
- Tutarlar: `1.250.000,00 TL`; önemli tutarlarda yazıyla: `1.250.000,00 TL (birmilyonikiyüzellibin Türk Lirası)`.
- Tarih: GG.AA.YYYY (nokta ayraçlı).
- Kurum adı ilk geçtiği yerde tam yazılır; sonra "Kurumunuz".
- Kararın öngörmediği yükümlülük, süre veya yorumu Kurum kararıymış gibi yazma.
- Gövdede "ekte sunulmaktadır" / "Ek-1" atıfları ek listesiyle bire bir uyumlu olsun.
